export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-logo">LearnSphere</div>
      <p className="footer-copy">© 2026 LearnSphere. All rights reserved. Built for curious minds.</p>
      <div style={{ display: "flex", gap: "1.5rem", fontSize: "1.4rem" }}>
        <span style={{ cursor: "pointer", opacity: 0.6, transition: "opacity 0.3s" }}
          onMouseEnter={e => e.target.style.opacity = 1}
          onMouseLeave={e => e.target.style.opacity = 0.6}>🐦</span>
        <span style={{ cursor: "pointer", opacity: 0.6, transition: "opacity 0.3s" }}
          onMouseEnter={e => e.target.style.opacity = 1}
          onMouseLeave={e => e.target.style.opacity = 0.6}>💼</span>
        <span style={{ cursor: "pointer", opacity: 0.6, transition: "opacity 0.3s" }}
          onMouseEnter={e => e.target.style.opacity = 1}
          onMouseLeave={e => e.target.style.opacity = 0.6}>📸</span>
      </div>
    </footer>
  );
}
