import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Login() {
  const [form, setForm] = useState({ email: "", password: "" });
  const navigate = useNavigate();
  const handle = e => setForm({ ...form, [e.target.name]: e.target.value });

  return (
    <div className="auth-page">
      <div className="auth-bg" />
      <div className="auth-card">
        <div className="auth-logo">🎓</div>
        <h1 className="auth-title">Welcome Back</h1>
        <p className="auth-sub">
          Don't have an account? <Link to="/signup">Sign up free</Link>
        </p>

        <div className="form-group">
          <label className="form-label">Email Address</label>
          <input className="form-input" name="email" type="email" value={form.email} onChange={handle} placeholder="you@email.com" />
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <input className="form-input" name="password" type="password" value={form.password} onChange={handle} placeholder="••••••••" />
        </div>

        <div style={{ textAlign: "right", marginBottom: "1.2rem" }}>
          <a href="#" style={{ fontSize: "0.85rem", color: "rgba(105,194,245,0.8)" }}>Forgot password?</a>
        </div>

        <button className="btn-primary" style={{ width: "100%", justifyContent: "center", padding: "0.9rem" }}
          onClick={() => navigate("/")}>
          Sign In →
        </button>

        <div className="auth-divider">or continue with</div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.8rem" }}>
          {[{ icon: "🔵", label: "Google" }, { icon: "⬛", label: "GitHub" }].map(p => (
            <button key={p.label} className="btn-secondary" style={{ justifyContent: "center", fontSize: "0.9rem" }}>
              {p.icon} {p.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
