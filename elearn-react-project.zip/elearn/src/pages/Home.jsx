import { useNavigate } from "react-router-dom";
import StatsSection from "../components/StatsSection";
import Footer from "../components/Footer";

const courses = [
  { thumb: "💻", bg: "linear-gradient(135deg, rgba(105,194,245,0.2), rgba(6,10,56,0.4))", category: "Development", level: "Beginner", name: "Full-Stack Web Dev Bootcamp", desc: "Build real-world apps from HTML to deployment with React & Node.js.", students: "12,400" },
  { thumb: "🤖", bg: "linear-gradient(135deg, rgba(60,200,100,0.2), rgba(6,10,56,0.4))", category: "AI & ML", level: "Intermediate", name: "Machine Learning Fundamentals", desc: "Understand algorithms, neural networks, and build intelligent models.", students: "8,900" },
  { thumb: "🎨", bg: "linear-gradient(135deg, rgba(255,150,80,0.2), rgba(6,10,56,0.4))", category: "Design", level: "All Levels", name: "UI/UX Design Mastery", desc: "Learn to craft beautiful, user-centered digital products from scratch.", students: "6,200" },
  { thumb: "📊", bg: "linear-gradient(135deg, rgba(200,100,255,0.2), rgba(6,10,56,0.4))", category: "Data Science", level: "Intermediate", name: "Data Analytics with Python", desc: "Analyze, visualize, and derive insights from complex datasets.", students: "9,700" },
  { thumb: "☁️", bg: "linear-gradient(135deg, rgba(105,194,245,0.2), rgba(6,10,56,0.4))", category: "Cloud", level: "Advanced", name: "AWS Cloud Architecture", desc: "Design scalable, secure cloud infrastructure on Amazon Web Services.", students: "4,500" },
  { thumb: "🔐", bg: "linear-gradient(135deg, rgba(255,80,80,0.2), rgba(6,10,56,0.4))", category: "Security", level: "Intermediate", name: "Ethical Hacking & Cybersecurity", desc: "Protect systems and networks with ethical hacking techniques.", students: "7,800" },
];

export default function Home() {
  const navigate = useNavigate();

  return (
    <>
      {/* HERO */}
      <section className="hero">
        <div className="hero-bg" />
        <div className="hero-grid" />
        <div className="hero-orb hero-orb-1" />
        <div className="hero-orb hero-orb-2" />

        <div className="hero-content">
          <div className="hero-badge">
            <div className="hero-badge-dot" />
            🚀 Next-Gen Learning Platform
          </div>

          <h1 className="hero-title">
            Unlock Your<br />
            <span className="highlight">Full Potential</span><br />
            Through Learning
          </h1>

          <p className="hero-subtitle">
            Access 1,200+ expert-crafted courses in tech, design, business, and beyond.
            Learn at your own pace, earn credentials, and transform your career.
          </p>

          <div className="hero-cta">
            <button className="btn-primary" onClick={() => navigate("/explore")}>
              Explore Courses →
            </button>
            <button className="btn-secondary" onClick={() => navigate("/signup")}>
              Start for Free
            </button>
          </div>
        </div>

        {/* Floating Card */}
        <div className="hero-visual">
          <div style={{ position: "relative" }}>
            <div className="floating-tag floating-tag-1">🎉 New: AI Courses</div>
            <div className="hero-card-floating">
              <div className="floating-card-header">
                <div className="avatar-stack">
                  {["A","B","C","D"].map(l => (
                    <div className="avatar" key={l}>{l}</div>
                  ))}
                </div>
                <div>
                  <div style={{ fontSize: "0.85rem", fontWeight: 600 }}>Active Learners</div>
                  <div style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.5)" }}>52,000+ this month</div>
                </div>
              </div>
              {[
                { name: "Web Development", pct: 82 },
                { name: "Machine Learning", pct: 67 },
                { name: "UI/UX Design", pct: 54 },
              ].map(c => (
                <div className="course-progress-item" key={c.name}>
                  <div className="cpi-top">
                    <span style={{ fontSize: "0.8rem" }}>{c.name}</span>
                    <span style={{ color: "rgba(105,194,245,0.9)", fontWeight: 600 }}>{c.pct}%</span>
                  </div>
                  <div className="cpi-bar">
                    <div className="cpi-fill" style={{ width: `${c.pct}%` }} />
                  </div>
                </div>
              ))}
            </div>
            <div className="floating-tag floating-tag-2">🏅 Certificate Included</div>
          </div>
        </div>
      </section>

      {/* STATS — animated numbers on scroll */}
      <StatsSection />

      {/* FEATURED COURSES */}
      <section className="section">
        <div className="section-header">
          <div className="section-tag">📖 Popular Courses</div>
          <h2 className="section-title">Start Learning Today</h2>
          <p className="section-subtitle">Hand-picked by our experts to boost your skills in the most in-demand fields.</p>
        </div>
        <div className="courses-grid">
          {courses.map((c, i) => (
            <div className="course-card" key={i}>
              <div className="course-thumb" style={{ background: c.bg }}>
                {c.thumb}
              </div>
              <div className="course-body">
                <div className="course-meta">
                  <span className="course-category">{c.category}</span>
                  <span className="course-level">{c.level}</span>
                </div>
                <div className="course-name">{c.name}</div>
                <p className="course-desc">{c.desc}</p>
                <div className="course-footer">
                  <span className="course-students">👥 {c.students} students</span>
                  <button className="course-btn" onClick={() => navigate("/explore")}>Enroll</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA BANNER */}
      <section style={{
        margin: "0 4rem 5rem",
        padding: "3.5rem",
        background: "linear-gradient(135deg, rgba(105,194,245,0.15), rgba(105,194,245,0.05))",
        border: "1px solid rgba(105,194,245,0.25)",
        borderRadius: "28px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: "2rem",
        position: "relative",
        overflow: "hidden"
      }}>
        <div style={{
          position: "absolute", top: 0, left: 0, right: 0, bottom: 0,
          background: "radial-gradient(ellipse 50% 80% at 80% 50%, rgba(105,194,245,0.12) 0%, transparent 70%)",
          pointerEvents: "none"
        }} />
        <div style={{ position: "relative" }}>
          <h2 style={{ fontFamily: "Syne, sans-serif", fontSize: "1.8rem", fontWeight: 800, marginBottom: "0.5rem" }}>
            Ready to level up your skills?
          </h2>
          <p style={{ color: "rgba(255,255,255,0.6)", maxWidth: 450 }}>
            Join 52,000+ learners. Get full access to all courses, certificates, and mentorship.
          </p>
        </div>
        <button className="btn-primary" style={{ position: "relative", fontSize: "1rem", padding: "1rem 2.5rem" }}
          onClick={() => navigate("/signup")}>
          Get Started Free →
        </button>
      </section>

      <Footer />
    </>
  );
}
