import Footer from "../components/Footer";

const team = [
  { emoji: "👨‍💼", name: "Alex Rivera", role: "CEO & Co-Founder" },
  { emoji: "👩‍💻", name: "Priya Sharma", role: "Head of Curriculum" },
  { emoji: "🧑‍🏫", name: "James Wu", role: "Lead Instructor" },
  { emoji: "👩‍🎨", name: "Mia Chen", role: "Head of Design" },
];

export default function About() {
  return (
    <>
      <div className="page-hero">
        <div className="page-hero-bg" />
        <div className="page-hero-content" style={{ textAlign: "center", margin: "0 auto" }}>
          <div className="page-tag">🌟 Our Story</div>
          <h1 className="page-title">Built by Learners,<br/>For Learners</h1>
          <p className="page-subtitle" style={{ margin: "0 auto" }}>
            We started LearnSphere with one belief: world-class education should be accessible to everyone, everywhere.
          </p>
        </div>
      </div>

      <div className="about-grid">
        <div className="about-visual">🌐</div>
        <div className="about-text">
          <h2>Our Mission is to Democratize Education</h2>
          <p>
            Founded in 2021, LearnSphere grew from a small team of passionate educators and engineers who believed
            that geography and resources shouldn't limit your potential to grow.
          </p>
          <p>
            Today we serve over 52,000 students across 120+ countries, offering courses across technology,
            design, business, and creative disciplines — all taught by industry practitioners.
          </p>
          <div className="about-features">
            {[
              "Self-paced, flexible learning for busy schedules",
              "Industry-recognized certificates upon completion",
              "Live mentorship sessions with expert instructors",
              "Community forums with 50,000+ active peers",
              "Lifetime access to all enrolled course materials",
            ].map(f => (
              <div className="feature-item" key={f}>
                <div className="feature-dot" />
                {f}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Team */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="section-header">
          <div className="section-tag">👥 The Team</div>
          <h2 className="section-title">Meet the Minds Behind It</h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "1.5rem", maxWidth: 1100, margin: "0 auto" }}>
          {team.map(m => (
            <div key={m.name} style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(105,194,245,0.15)",
              borderRadius: 20,
              padding: "2rem",
              textAlign: "center",
              transition: "all 0.3s",
              cursor: "default"
            }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = "rgba(105,194,245,0.4)";
                e.currentTarget.style.transform = "translateY(-5px)";
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = "rgba(105,194,245,0.15)";
                e.currentTarget.style.transform = "translateY(0)";
              }}>
              <div style={{ fontSize: "3.5rem", marginBottom: "1rem" }}>{m.emoji}</div>
              <div style={{ fontFamily: "Syne, sans-serif", fontWeight: 700, marginBottom: "0.3rem" }}>{m.name}</div>
              <div style={{ fontSize: "0.85rem", color: "rgba(105,194,245,0.9)" }}>{m.role}</div>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </>
  );
}
