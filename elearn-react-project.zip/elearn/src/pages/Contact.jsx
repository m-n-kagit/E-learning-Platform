import { useState } from "react";
import Footer from "../components/Footer";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });

  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = () => {
    if (form.name && form.email && form.message) setSubmitted(true);
  };

  return (
    <>
      <div className="page-hero">
        <div className="page-hero-bg" />
        <div className="page-hero-content" style={{ textAlign: "center", margin: "0 auto" }}>
          <div className="page-tag">📬 Reach Out</div>
          <h1 className="page-title">We'd Love to Hear From You</h1>
          <p className="page-subtitle" style={{ margin: "0 auto" }}>
            Questions, feedback, partnerships — our team is here and ready to help.
          </p>
        </div>
      </div>

      <div className="contact-layout">
        <div className="contact-info">
          <h2>Get in Touch</h2>
          <p>Our support team typically responds within 2–4 business hours. We're here to help with anything.</p>
          <div className="contact-items">
            {[
              { icon: "📧", label: "Email", value: "hello@learnsphere.io" },
              { icon: "📞", label: "Phone", value: "+1 (800) 555-LEARN" },
              { icon: "📍", label: "Office", value: "San Francisco, CA 94105" },
              { icon: "🕒", label: "Hours", value: "Mon–Fri, 9am–6pm PST" },
            ].map(item => (
              <div className="contact-item" key={item.label}>
                <div className="ci-icon">{item.icon}</div>
                <div>
                  <div className="ci-label">{item.label}</div>
                  <div className="ci-value">{item.value}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="contact-form">
          {submitted ? (
            <div style={{ textAlign: "center", padding: "3rem 0" }}>
              <div style={{ fontSize: "4rem", marginBottom: "1rem" }}>✅</div>
              <h3 style={{ fontFamily: "Syne, sans-serif", fontSize: "1.4rem", marginBottom: "0.5rem" }}>Message Sent!</h3>
              <p style={{ color: "rgba(255,255,255,0.6)" }}>We'll get back to you shortly.</p>
              <button className="btn-primary" style={{ marginTop: "1.5rem" }} onClick={() => { setSubmitted(false); setForm({ name: "", email: "", subject: "", message: "" }); }}>
                Send Another
              </button>
            </div>
          ) : (
            <>
              <h3 style={{ fontFamily: "Syne, sans-serif", fontSize: "1.3rem", marginBottom: "1.5rem" }}>Send a Message</h3>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                <div className="form-group">
                  <label className="form-label">Your Name</label>
                  <input className="form-input" name="name" value={form.name} onChange={handle} placeholder="John Doe" />
                </div>
                <div className="form-group">
                  <label className="form-label">Email Address</label>
                  <input className="form-input" name="email" value={form.email} onChange={handle} placeholder="john@email.com" />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Subject</label>
                <input className="form-input" name="subject" value={form.subject} onChange={handle} placeholder="How can we help?" />
              </div>
              <div className="form-group">
                <label className="form-label">Message</label>
                <textarea className="form-textarea" name="message" value={form.message} onChange={handle} placeholder="Tell us more about your inquiry..." />
              </div>
              <button className="btn-primary" style={{ width: "100%", justifyContent: "center" }} onClick={submit}>
                Send Message →
              </button>
            </>
          )}
        </div>
      </div>

      <Footer />
    </>
  );
}
