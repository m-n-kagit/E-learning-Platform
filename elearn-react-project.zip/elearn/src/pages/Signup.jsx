import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Signup() {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const navigate = useNavigate();
  const handle = e => setForm({ ...form, [e.target.name]: e.target.value });

  return (
    <div className="auth-page">
      <div className="auth-bg" />
      <div className="auth-card">
        <div className="auth-logo">🚀</div>
        <h1 className="auth-title">Create Account</h1>
        <p className="auth-sub">
          Already have an account? <Link to="/login">Sign in</Link>
        </p>

        <div className="form-group">
          <label className="form-label">Full Name</label>
          <input className="form-input" name="name" value={form.name} onChange={handle} placeholder="John Doe" />
        </div>
        <div className="form-group">
          <label className="form-label">Email Address</label>
          <input className="form-input" name="email" type="email" value={form.email} onChange={handle} placeholder="you@email.com" />
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <input className="form-input" name="password" type="password" value={form.password} onChange={handle} placeholder="Min. 8 characters" />
        </div>

        <p style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.45)", marginBottom: "1.2rem" }}>
          By signing up, you agree to our <a href="#" style={{ color: "rgba(105,194,245,0.7)" }}>Terms of Service</a> and <a href="#" style={{ color: "rgba(105,194,245,0.7)" }}>Privacy Policy</a>.
        </p>

        <button className="btn-primary" style={{ width: "100%", justifyContent: "center", padding: "0.9rem" }}
          onClick={() => navigate("/")}>
          Create Account →
        </button>

        <div className="auth-divider">or sign up with</div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.8rem" }}>
          {[{ icon: "🔵", label: "Google" }, { icon: "⬛", label: "GitHub" }].map(p => (
            <button key={p.label} className="btn-secondary" style={{ justifyContent: "center", fontSize: "0.9rem" }}>
              {p.icon} {p.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
