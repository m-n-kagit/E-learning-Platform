import { useState } from "react";
import Footer from "../components/Footer";

const categories = [
  { icon: "💻", name: "Web Development", count: "180+ courses", color: "rgba(105,194,245,0.15)" },
  { icon: "🤖", name: "AI & Machine Learning", count: "95+ courses", color: "rgba(60,200,100,0.12)" },
  { icon: "🎨", name: "UI/UX Design", count: "120+ courses", color: "rgba(255,150,80,0.12)" },
  { icon: "📊", name: "Data Science", count: "110+ courses", color: "rgba(200,100,255,0.12)" },
  { icon: "☁️", name: "Cloud & DevOps", count: "75+ courses", color: "rgba(105,194,245,0.1)" },
  { icon: "🔐", name: "Cybersecurity", count: "60+ courses", color: "rgba(255,80,80,0.1)" },
  { icon: "📱", name: "Mobile Development", count: "88+ courses", color: "rgba(255,200,60,0.1)" },
  { icon: "💰", name: "Business & Finance", count: "140+ courses", color: "rgba(60,255,180,0.1)" },
  { icon: "🎬", name: "Video & Photography", count: "55+ courses", color: "rgba(255,80,200,0.1)" },
];

export default function Explore() {
  const [search, setSearch] = useState("");
  const filtered = categories.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <div className="page-hero">
        <div className="page-hero-bg" />
        <div className="page-hero-content" style={{ textAlign: "center", margin: "0 auto", width: "100%" }}>
          <div className="page-tag">🔍 Browse All</div>
          <h1 className="page-title">Explore Every Discipline</h1>
          <p className="page-subtitle" style={{ margin: "0 auto 2rem" }}>
            From foundational skills to advanced specializations — find exactly what you want to master.
          </p>
          <input
            className="form-input"
            placeholder="🔍  Search categories..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ maxWidth: 450, margin: "0 auto", display: "block" }}
          />
        </div>
      </div>

      <div className="explore-grid">
        {filtered.map((c, i) => (
          <div className="category-card" key={i} style={{ background: c.color }}>
            <div className="cat-icon">{c.icon}</div>
            <div className="cat-name">{c.name}</div>
            <div className="cat-count">{c.count}</div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div style={{ gridColumn: "1/-1", textAlign: "center", padding: "3rem", color: "rgba(255,255,255,0.4)" }}>
            No categories match your search.
          </div>
        )}
      </div>

      <Footer />
    </>
  );
}
