# LearnSphere – E-Learning Platform

A clean, sober React + React Router e-learning platform UI.

## Tech Stack
- React 18
- React Router v6
- Vite
- Plain CSS (Inter font)

## Getting Started

### 1. Install dependencies
```bash
npm install
```

### 2. Start development server
```bash
npm run dev
```

### 3. Open in browser
Visit `http://localhost:5173`

## Project Structure
```
src/
├── App.jsx                     # Router setup
├── main.jsx                    # Entry point
├── styles.css                  # Global styles
├── components/
│   ├── Navbar.jsx              # Top navigation bar
│   ├── Footer.jsx              # Page footer
│   ├── AnimatedCounter.jsx     # Scroll-triggered number animation
│   └── StatsSection.jsx        # Stats row with animated counters
└── pages/
    ├── Home.jsx                # Landing page
    ├── About.jsx               # About Us page
    ├── Explore.jsx             # Course categories + search
    ├── Contact.jsx             # Contact form
    ├── Login.jsx               # Login page
    └── Signup.jsx              # Sign up page
```

## Build for Production
```bash
npm run build
```
Output will be in the `dist/` folder.
